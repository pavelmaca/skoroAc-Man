import java.awt.*;

/**
 * Created by Admin on 4.3.2016.
 */
public class baf {
    public static void main(String[] args) {
        vykresliBaf();
    }

    private static void vykresliBaf() {
    }


}
