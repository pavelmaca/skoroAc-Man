import java.awt.*;

/**
 * Created by Admin on 28.2.2016.
 */
public class OkrajeP1 {
    public Rectangle getOkraje(){return new Rectangle(50, 40, 70, 210);}
}
